﻿using MessagePack;
using System.ComponentModel.DataAnnotations;
using KeyAttribute = System.ComponentModel.DataAnnotations.KeyAttribute;

namespace ICTsolutions.Models
{
    public class Client
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [DataType(DataType.EmailAddress)]
        public int Email { get; set; }

        [Required]
        public string CompanyName { get; set; }

        [DataType(DataType.PhoneNumber)]
        public string Phonenumber { get; set; }

        [Required]
        public List<Project> projects { get; set; }

    }
}
