﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace ICTsolutions.Enums
{
    public enum PaymentEnum
    {
        [Display(Name = "Volunteer")]
        Volunteer,

        [Display(Name = "Money")]
        Money,

        [Display(Name = "ECTS")]
        Ects

    }
}
