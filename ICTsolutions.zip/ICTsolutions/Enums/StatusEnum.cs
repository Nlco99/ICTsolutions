﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace ICTsolutions.Enums
{
    public enum StatusEnum
    {
        [Display(Name = "Available")]
        Available,

        [Display(Name = "Active")]
        Active,

        [Display(Name = "Completed")]
        Completed
    }
}
