﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace ICTsolutions.Enums
{
    public enum TypeEnum
    {
        [Display(Name = "Internship")]
        Internship,

        [Display(Name = "Graduation Assignment")]
        GraduationAssignment,

        [Display(Name = "Work")]
        Work
    }
}
